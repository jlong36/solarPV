from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from .forms import SignUpForm
from backend.models import Certificate


# Create your views here.

def index(request):
    return render(request, 'frontend/index.html' )

def signup_view(request):
    form = SignUpForm(request.POST)
    if form.is_valid():
        user = form.save()
        user.refresh_from_db()
        user.profile.first_name = form.cleaned_data.get('first_name')
        user.profile.last_name = form.cleaned_data.get('last_name')
        user.profile.company = form.cleaned_data.get('company')
        user.profile.email = form.cleaned_data.get('email')
        user.profile.job_title = form.cleaned_data.get('job_title')
        user.save()

        return redirect('index')
    else:
        form = SignUpForm()
    return render(request, 'frontend/contact.html', {'form': form})


def search(request):
    certification = Certificate.objects.order_by('standardID')
    context = {'certification' : certification}
    return render(request, 'frontend/search.html', context)

def aboutUs(request):
    return render(request, 'frontend/aboutus.html')

def privacyPolicy(request):
    return render(request, 'frontend/privacypolicy.html')

def pvSystems(request):
    return render(request, 'frontend/pvsystems.html')

def siteMap(request):
    return render(request, 'frontend/sitemap.html')

def socialMediaLinks(request):
    return render(request, 'frontend/socialmedialinks.html')